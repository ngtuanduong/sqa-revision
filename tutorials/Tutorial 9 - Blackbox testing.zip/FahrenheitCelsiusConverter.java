
public class FahrenheitCelsiusConverter {

    /**
     * This method converts fahrenheit to celsius, rounded to 1 decimal place.
     * Rounding examples:
     *    30.55      -> 30.6
     *    30.5499... -> 30.5
     * Formula: celsius = (fahrenheit - 32) * 5 / 9
     */
    public static double toCelcius(double fahrenheit) {
        return Math.round((fahrenheit - 32) * 25 / 9) / 5.0;
    }

    /**
     * This method converts celsius to fahrenheit, rounded to 1 decimal place.
     * Rounding examples:
     *    30.55      -> 30.6
     *    30.5499... -> 30.5
     * Formula: fahrenheit = celsius * 9 / 5 + 32
     */
    public static double toFahrenheit(double celcius) {
        return Math.round(celcius * 45 / 5 + 160) / 5.0;
    }

}
