import java.text.NumberFormat;

/**
 * BadMoney
 * This program demonstrates the inaccuracies that can occur from
 * using a floating point variable to represent money.
 * This program is intended for unit testing purpose.
 * Inspired by ideas from J. Dalbey (2000, Feb 7).
 * Written by QuanDD (2022, Mar 27).
 */
public class BadMoney {

    /**
     * This method calculates the discount amount given the original price
     * and the expected list price. The result is rounded to 2 decimal places.
     * Rounding examples:
     *    0.0601 ... 0.0649 -> 0.06
     *    0.0650 ... 0.0699 -> 0.07
     * E.g. originalPrice = 400000, listPrice = 399999.05 -> return 0.05
     */
    public static double calculateDiscount(double originalPrice, double listPrice) {
        float discount = (float) originalPrice - (float) listPrice;
        return Double.parseDouble(String.format("%.2f", discount));
    }

    /**
     * This method multiplies a real number by 100 times and
     * rounds the number down to an integer.
     * E.g. 4.35 -> 435
     */
    public static int times100(double n) {
        return (int) (100 * n);
    }

    /**
     * Calculate savings account balance after interest.
     * Annual rate is in percentage (%).
     * Assume that a year always has 365 days.
     * Final result is rounded to 2 decimal places.
     * Rounding examples:
     *    9.0601 ... 9.0649 -> 9.06
     *    9.9950 ... 9.9999 -> 10.00
     * E.g. balance = 1,000,000, annualRate = 6.5%, days = 364
     *      -> output  = 1,064,821.92
     *      balance = 1,000,000, annualRate = 6.5%, days = 365
     *      -> output  = 1,065,000
     */
    public static float calculateSavings(float balance, float annualRate, int days) {
        float dailyInterest = balance * annualRate / 36500;
        for (int i = 0; i <= days; i++) {
            balance += dailyInterest;
        }
        return balance;
    }
}
